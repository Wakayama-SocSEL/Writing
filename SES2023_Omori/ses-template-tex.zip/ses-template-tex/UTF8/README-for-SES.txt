本ディレクトリには，情報処理学会で提供されている LaTeXスタイルファイル for UTF8 
(2018/08/03 v4.0) に対して，ソフトウェアエンジニアリングシンポジウム用に修正を加
えたものです．
https://www.ipsj.or.jp/journal/submit/style.html

オリジナルのファイルのうち，以下の修正を加えたものです．

  - ipsj.cls        (修正)
  - ses.sty         (追加)
  - ses-sample.tex  (追加)
  - ses-esample.tex (追加)
  
  - ipsj*.sty       (削除)
  - jsample.tex     (削除)
  - esample.tex     (削除)
  - tech-jsample.*  (削除)

SES への論文は，ses-sample.tex(日本語用)，ses-esample.tex(英語用) をもとにご作成
下さい．

これらのファイルは，研究報告用のスタイル ipsjtech.sty およびそのサンプル 
tech-jsample.tex, tech-esample.tex をもとに，以下の修正を加えたものです．

  - ヘッダー，フッターを削除
  - ページ番号の付与を停止

何か不具合がございましたら，SES運営委員会までお知らせください．
